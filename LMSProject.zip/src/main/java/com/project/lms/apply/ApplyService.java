package com.project.lms.apply;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.project.lms.DataNotFoundException;
import com.project.lms.course.Course;
import com.project.lms.course.CourseRepository;
import com.project.lms.member.Member;
import com.project.lms.member.Role;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ApplyService {
	
	private final ApplyRepository applyRepository;
	private final CourseRepository courseRepository;
	
	//신청
	public Apply enroll(Member member, Course course) {
		if (member.getRole() == Role.INSTRUCTOR) {
			throw new IllegalStateException("강사는 수강 신청이 불가능합니다."); 
		}
		if (applyRepository.existsByMemberAndCourseAndStatus(member, course, 1)) {
			throw new DataNotFoundException("이미 신청완료 강좌");
		} 
		Apply apply = new Apply();
		apply.setMember(member);
		apply.setCourse(course);
		apply.setApldate(LocalDateTime.now());
		apply.setStatus(1);
		return applyRepository.save(apply);
	}
	
	//신청 목록 조회
	public List<Apply> getApplyByMember(Member member){
		return applyRepository.findByMember(member);
	}
	
	//수강취소 >> 수강신청상태를 0으로 바꾸기
	public void cancle(Apply apply) {
		if(apply.getStatus() == 0) {
			throw new IllegalStateException("이미 취소된 강좌입니다.");
		}
		apply.setStatus(0);
		applyRepository.save(apply);
	}
	
	public Apply getApply(Integer applyno) {
		return applyRepository.findById(applyno).orElseThrow(() -> new DataNotFoundException("신청내역이 없습니다."));
	}
}