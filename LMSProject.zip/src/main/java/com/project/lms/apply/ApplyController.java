package com.project.lms.apply;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.lms.DataNotFoundException;
import com.project.lms.course.Course;
import com.project.lms.course.CourseService;
import com.project.lms.member.Member;
import com.project.lms.member.MemberService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/apply")
public class ApplyController {
	
	private final ApplyService applyService;
	private final MemberService memberService;
	private final CourseService courseService;
	
	//강좌 신청
	@PostMapping("/course/{courseno}")
	public String ApplyCourse(@PathVariable("courseno") Integer courseno, Principal principal) {
		Member member = memberService.getMember(principal.getName());
		Course course = courseService.getCourse(courseno);
		
		try {
			applyService.enroll(member, course);
			System.out.println("수강신청완료"); //에러 나서 콘솔창 확인용
		} catch(IllegalStateException e) {
			System.out.println("예외 발생 : "+e.getMessage());
			return "redirect:/course/detail/"+courseno+"?forbidden";
		} catch (DataNotFoundException e) {
			System.out.println("예외 발생 : "+e.getMessage());
			return "redirect:/course/detail/" + courseno + "?error";
		} 
		return "redirect:/course/detail/" + courseno + "?success";
	}
	
	//수강 신청 목록 조회
	@GetMapping("/list")
	public String ApplyList(Model model, Principal principal) {
		if(principal == null) {
			return "redirect:/member/login";
		}
		Member member = memberService.getMember(principal.getName());
		List<Apply> applyList = applyService.getApplyByMember(member);		
		//모든 강좌 취소후 수강중인 강좌가 없을때 리스트가 떠서 수강상태일때만 확인
		boolean hasActiveApplications = applyList.stream()
                .anyMatch(apply -> apply.getStatus() == 1);
		
		model.addAttribute("applyList",applyList);
        model.addAttribute("hasActiveApplications", hasActiveApplications); //뷰 전달
		
		return "myclass";
	}
	
	//취소
	@PostMapping("/cancel/{applyno}")
	public String ApplyCancel(@PathVariable("applyno") Integer applyno, Principal principal) {
		if(principal == null) {
			return "redirect:/member/login";
		}
		
		Member member = memberService.getMember(principal.getName());
		Apply apply = applyService.getApply(applyno);
		
		applyService.cancle(apply);
		return "redirect:/apply/list";
	}
}