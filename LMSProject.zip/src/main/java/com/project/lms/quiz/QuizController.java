package com.project.lms.quiz;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.lms.lesson.Lesson;
import com.project.lms.lesson.LessonService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/quiz")
public class QuizController {
	
	private final QuizService quizService;
	private final LessonService lessonService;
	
	//퀴즈 리스트
	@GetMapping("/list")
	public String list(Model model) {
		List<Quiz> quizList = quizService.getList();
		model.addAttribute("quizList", quizList);
		return "quizListTest";
	}
	
	//퀴즈 정보 상세조회
	@GetMapping("/detail/{quizno}")
	public String detail(Model model, @PathVariable("quizno") Integer quizno) {
		Quiz quiz = quizService.getQuiz(quizno);
		model.addAttribute("quiz", quiz);
		return "quizDetailTest"; //아직 안만듬 나중에 퀴즈 문제 생성할때 만들 예정 
	}
	
	//퀴즈 정보 생성창 불러오기
	@GetMapping("/create/{lessonno}")
	public String quizCreate(Model model, @PathVariable("lessonno") Integer lessonno, QuizForm quizForm) {
		Lesson lesson = lessonService.getLesson(lessonno);
		model.addAttribute("lesson", lesson);
		return "quizCreateTest";
	}
	
	//퀴즈 정보 생성하기
	@PostMapping("/create/{lessonno}")
	public String quizCreate(Model model, @PathVariable("lessonno") Integer lessonno, @Valid QuizForm quizForm, BindingResult bindingResult) {
		Lesson lesson = lessonService.getLesson(lessonno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("lesson", lesson);
			return "quizCreateTest";
		}
		quizService.create(quizForm.getTitle(), quizForm.getTotalpoint(), lesson);
		return String.format("redirect:/lesson/detail/%s", lessonno);		
	}
	
	//퀴즈 정보 수정
	@GetMapping("/modify/{quizno}")
	public String quizModify(Model model, @PathVariable("quizno") Integer quizno) {
		Quiz quiz = quizService.getQuiz(quizno);
		QuizForm quizForm = new QuizForm();
		quizForm.setTitle(quiz.getTitle());
		quizForm.setTotalpoint(quiz.getTotalpoint());
		model.addAttribute("quizForm", quizForm);
		model.addAttribute("quiz", quiz);
		return "quizModifyTest";
	}
	
	@PostMapping("/modify/{quizno}")
	public String quizModify(Model model, @PathVariable("quizno") Integer quizno, @Valid QuizForm quizForm, BindingResult bindingResult) {
		Quiz quiz = quizService.getQuiz(quizno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("quiz", quiz);
			return "quizModifyTest";
		}
		quizService.modify(quiz, quizForm.getTitle(), quizForm.getTotalpoint());
		return String.format("redirect:/quiz/detail/%s", quizno);
	}
	
	//삭제
	@PostMapping("/delete/{quizno}")
	public String quizDelete(@PathVariable("quizno") Integer quizno) {
		Quiz quiz = quizService.getQuiz(quizno);
		quizService.delete(quiz);
		return String.format("redirect:/lesson/detail/%s", quiz.getLesson().getLessonno());
	}
}