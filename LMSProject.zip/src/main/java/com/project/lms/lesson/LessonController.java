package com.project.lms.lesson;

import java.security.Principal;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.lms.course.Course;
import com.project.lms.course.CourseService;
import com.project.lms.member.Member;
import com.project.lms.member.MemberService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/lesson")
public class LessonController {
	private final LessonService lessonService;
	private final CourseService courseService;
	private final MemberService memberService;

	
	//전체 리스트
	@GetMapping("/list")
	public String list(Model model) {
		List<Lesson> lessonList = lessonService.getList();
		model.addAttribute("lessonList", lessonList);
		return "lessonListTest";
	}
	
	//하나 조회
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/detail/{lessonno}")
	public String detail(Model model, 
						 @PathVariable("lessonno") Integer lessonno) {
		Lesson lesson = lessonService.getLesson(lessonno);
		model.addAttribute("lesson", lesson);
		
		Course course = lesson.getCourse();
		model.addAttribute("course", course);
		model.addAttribute("lessonList", course.getLessonList());
		return "lesson_detail";
	}
	
	//생성 정보 불러오기
	@PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
	@GetMapping("/create/{courseno}")
	public String lessonCreate(Model model, 
							   @PathVariable("courseno") Integer courseno, 
							   LessonForm lessonForm,
							   Principal principal) {
		Course course = courseService.getCourse(courseno);
		
		// 로그인한 사람의 id를 가져오는 loginMember, 강사가 null이거나 강좌의 강사 id가 같지 않으면 리스트로 리다이렉트
		String loginMember = principal.getName();
		Member member = memberService.getMember(loginMember);
		boolean isAdmin = member.getRole().name().equals("ADMIN");
		
        if(course.getInstructor() == null || !course.getInstructor().getMemberid().equals(loginMember)) {
        	if(!isAdmin) {
        	return "redirect:/course/list";
        	}
        }
        
		model.addAttribute("course", course);
		return "lesson_create";
	}
	
	//생성하기
	@PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
	@PostMapping("/create/{courseno}")
	public String lessonCreate(Model model, 
							   @PathVariable("courseno") Integer courseno, 
							   @Valid LessonForm lessonForm, 
							   BindingResult bindingResult) {
		Course course = courseService.getCourse(courseno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("course", course);
			return "lesson_create";
		}
		lessonService.create(lessonForm.getTitle(), lessonForm.getContent(), lessonForm.getVideo(), lessonForm.getTime(), course);
		return String.format("redirect:/course/detail/%s", courseno);
	}
	
	//수정 getmapping (조회)
	@PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
	@GetMapping("/modify/{lessonno}")
	public String lessonModify(Model model, 
							   @PathVariable("lessonno") Integer lessonno,
							   Principal principal) {
		Lesson lesson = lessonService.getLesson(lessonno);
		
		// 로그인한 사람의 id를 가져오는 loginMember, 강사가 null이거나 강의 정보의 강좌의 강사 id가 같지 않으면 리스트로 리다이렉트       
		String loginMember = principal.getName();
		Member member = memberService.getMember(loginMember);
		boolean isAdmin = member.getRole().name().equals("ADMIN");
		
		if(lesson.getCourse().getInstructor() == null || !lesson.getCourse().getInstructor().getMemberid().equals(loginMember)) {
			if(!isAdmin) {
			return "redirect:/course/list";
			}
		}
		
		LessonForm lessonForm = new LessonForm();
		
		lessonForm.setLessonno(lesson.getLessonno());
		lessonForm.setTitle(lesson.getTitle());
		lessonForm.setContent(lesson.getContent());
		lessonForm.setVideo(lesson.getVideo());
		lessonForm.setTime(lesson.getTime());
		model.addAttribute("lessonForm", lessonForm);
		model.addAttribute("lesson", lesson);
		return "lesson_modify";
	}
	
	//수정 입력 (post)
	@PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
	@PostMapping("/modify/{lessonno}")
	public String lessonModify(Model model, 
							   @PathVariable("lessonno") Integer lessonno, 
							   @Valid LessonForm lessonForm, 
							   BindingResult bindingResult) {
		Lesson lesson = lessonService.getLesson(lessonno);
		if(bindingResult.hasErrors()) {
			model.addAttribute("lesson", lesson);
			return "lesson_modify";
		}
		lessonService.modify(lesson, 
							 lessonForm.getTitle(), 
							 lessonForm.getContent(), 
							 lessonForm.getVideo(), 
							 lessonForm.getTime());
		Integer courseno = lesson.getCourse().getCourseno();
		return "redirect:/course/detail/"+ courseno;
	}
	
	//삭제
	@PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
	@PostMapping("/delete/{lessonno}")
	public String lessonDelete(@PathVariable("lessonno") Integer lessonno) {
		Lesson lesson = lessonService.getLesson(lessonno);
		lessonService.delete(lesson);
		
		Integer courseno = lesson.getCourse().getCourseno();

		return "redirect:/course/detail/"+ courseno;
	}
}
