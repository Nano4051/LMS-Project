package com.project.lms.attendance;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.lms.member.Member;

public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {
	
	boolean existsByMemberAndAttdate(Member member, LocalDate attDate); //오늘 출석했는지 확인
}