package com.project.lms.course;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.project.lms.category.Category;
import com.project.lms.member.Member;

public interface CourseRepository extends JpaRepository<Course, Integer> {
	
	//페이징
	Page<Course> findAll(Pageable pageable);
	Page<Course> findAll(Specification<Course> spec, Pageable pageable);
	Page<Course> findByCategory(Category category, Pageable pageable);
	Page<Course> findByInstructor(Member instructor, Pageable pageable);//강사의 강좌리스트를 조회
}
